/**
 * AdShield Pro - Universal Content Script
 * Works across Mozilla Firefox, Google Chrome, Microsoft Edge, Brave, and Opera.
 */

(() => {
  'use strict';

  const ext = typeof browser !== 'undefined' ? browser : chrome;

  let isEnabled = true;
  let isWhitelisted = false;
  let blockedCountOnPage = 0;
  let zapperActive = false;
  let hoveredElement = null;

  const currentHost = window.location.hostname;

  // Comprehensive ad selectors for programmatic scanning & removal
  const AD_SELECTORS = [
    'ins.adsbygoogle',
    '.adsbox',
    '.ad-banner',
    '.ad-container',
    '.ad-slot',
    '.ad-unit',
    '.ad-placement',
    '.top-ad',
    '.sidebar-ad',
    '.bottom-ad-bar',
    '.sticky-ad-wrapper',
    '.floating-ad',
    '[id^="google_ads_"]',
    '[id^="div-gpt-ad"]',
    '[id^="dfp-ad-"]',
    '.outbrain',
    '.taboola',
    '.revcontent',
    '.mgid',
    'iframe[src*="doubleclick.net"]',
    'iframe[src*="googlesyndication.com"]',
    'iframe[src*="googleadservices.com"]',
    'iframe[src*="adnxs.com"]',
    'iframe[src*="amazon-adsystem.com"]',
    'iframe[id^="aswift_"]',
    'iframe[id^="google_ads_frame"]',
    '[aria-label="advertisement" i]',
    '[aria-label="sponsored" i]'
  ];

  const SELECTOR_QUERY = AD_SELECTORS.join(', ');

  // Initialize settings from storage
  ext.storage.local.get(['adshield_enabled', 'adshield_whitelist', 'adshield_custom_rules'], (result) => {
    isEnabled = result.adshield_enabled !== false;
    const whitelist = result.adshield_whitelist || [];
    isWhitelisted = whitelist.includes(currentHost);

    if (!isEnabled || isWhitelisted) {
      return;
    }

    // Apply any saved custom zapped selectors for this domain
    const customRules = result.adshield_custom_rules || {};
    const siteRules = customRules[currentHost] || [];
    applyCustomSelectors(siteRules);

    // Initial DOM cleanup
    scanAndRemoveAds();

    // Start continuous observer for dynamic / infinite-scroll ads
    startAdObserver();

    // Setup video ad skipper
    setupVideoAdSkipper();
  });

  /**
   * Scan DOM and remove all matched advertising nodes
   */
  function scanAndRemoveAds() {
    if (!isEnabled || isWhitelisted) return;

    try {
      const adElements = document.querySelectorAll(SELECTOR_QUERY);
      if (adElements.length > 0) {
        let removedThisPass = 0;
        adElements.forEach((el) => {
          if (!el.dataset.adshieldProcessed) {
            el.dataset.adshieldProcessed = 'true';
            el.style.setProperty('display', 'none', 'important');
            el.style.setProperty('visibility', 'hidden', 'important');
            el.style.setProperty('height', '0px', 'important');
            el.style.setProperty('min-height', '0px', 'important');
            el.style.setProperty('margin', '0px', 'important');
            el.style.setProperty('padding', '0px', 'important');
            
            try {
              if (el.parentNode && el.tagName !== 'BODY' && el.tagName !== 'HTML') {
                el.remove();
              }
            } catch (e) {}

            removedThisPass++;
          }
        });

        if (removedThisPass > 0) {
          blockedCountOnPage += removedThisPass;
          notifyBlockedAds(removedThisPass);
        }
      }
    } catch (e) {}
  }

  /**
   * Setup MutationObserver to catch dynamically injected ads
   */
  function startAdObserver() {
    let debounceTimer = null;
    const observer = new MutationObserver(() => {
      if (debounceTimer) return;
      debounceTimer = setTimeout(() => {
        scanAndRemoveAds();
        debounceTimer = null;
      }, 100);
    });

    if (document.body) {
      observer.observe(document.body, { childList: true, subtree: true });
    } else {
      document.addEventListener('DOMContentLoaded', () => {
        if (document.body) {
          observer.observe(document.body, { childList: true, subtree: true });
        }
      });
    }
  }

  /**
   * Automatic video ad skipper & fast-forwarder
   */
  function setupVideoAdSkipper() {
    setInterval(() => {
      if (!isEnabled || isWhitelisted) return;

      const skipButtons = [
        '.ytp-ad-skip-button',
        '.ytp-ad-skip-button-modern',
        '.videoAdUiSkipButton',
        '[id^="skip-button:"] button',
        '.ytp-skip-ad-button'
      ];

      for (const sel of skipButtons) {
        const btn = document.querySelector(sel);
        if (btn) {
          btn.click();
          blockedCountOnPage++;
          notifyBlockedAds(1);
          break;
        }
      }

      const player = document.querySelector('.html5-video-player');
      if (player && player.classList.contains('ad-showing')) {
        const video = player.querySelector('video');
        if (video && !isNaN(video.duration)) {
          video.currentTime = video.duration;
          video.playbackRate = 16.0;
        }
      }
    }, 500);
  }

  /**
   * Send blocked count to background script
   */
  function notifyBlockedAds(count) {
    try {
      ext.runtime.sendMessage({
        action: 'adBlocked',
        count: count,
        url: window.location.href,
        host: currentHost
      });
    } catch (e) {}
  }

  /**
   * Apply user custom zapped CSS selectors
   */
  function applyCustomSelectors(selectors) {
    if (!selectors || selectors.length === 0) return;
    const styleId = 'adshield-custom-style';
    let styleEl = document.getElementById(styleId);
    if (!styleEl) {
      styleEl = document.createElement('style');
      styleEl.id = styleId;
      document.head.appendChild(styleEl);
    }
    styleEl.textContent = selectors.join(', ') + ' { display: none !important; visibility: hidden !important; }';
  }

  // ==========================================
  // ELEMENT ZAPPER / PICKER TOOL
  // ==========================================

  function startZapperMode() {
    if (zapperActive) return;
    zapperActive = true;

    const banner = document.createElement('div');
    banner.id = 'adshield-zapper-banner';
    banner.innerHTML = `
      <div style="
        position: fixed; top: 16px; left: 50%; transform: translateX(-50%);
        background: #111827; color: #fff; padding: 12px 24px; border-radius: 9999px;
        box-shadow: 0 10px 25px rgba(0,0,0,0.5); z-index: 2147483647;
        font-family: system-ui, -apple-system, sans-serif; font-size: 14px;
        font-weight: 600; display: flex; align-items: center; gap: 12px;
        border: 2px solid #ef4444; pointer-events: auto;
      ">
        <span style="color: #ef4444; font-size: 18px;">⚡</span>
        <span>AdShield Zapper: Hover & click any annoying ad/element to delete it.</span>
        <button id="adshield-zapper-exit" style="
          background: #374151; color: white; border: none; padding: 4px 10px;
          border-radius: 6px; cursor: pointer; font-size: 12px;
        ">ESC to Exit</button>
      </div>
    `;
    document.body.appendChild(banner);

    document.getElementById('adshield-zapper-exit').addEventListener('click', stopZapperMode);

    document.addEventListener('mouseover', onZapperHover, true);
    document.addEventListener('mouseout', onZapperUnhover, true);
    document.addEventListener('click', onZapperClick, true);
    document.addEventListener('keydown', onZapperKeyDown, true);
  }

  function stopZapperMode() {
    zapperActive = false;
    if (hoveredElement) {
      hoveredElement.classList.remove('adshield-picker-target');
      hoveredElement = null;
    }
    const banner = document.getElementById('adshield-zapper-banner');
    if (banner) banner.remove();

    document.removeEventListener('mouseover', onZapperHover, true);
    document.removeEventListener('mouseout', onZapperUnhover, true);
    document.removeEventListener('click', onZapperClick, true);
    document.removeEventListener('keydown', onZapperKeyDown, true);
  }

  function onZapperHover(e) {
    if (!zapperActive) return;
    if (e.target.closest('#adshield-zapper-banner')) return;
    if (hoveredElement && hoveredElement !== e.target) {
      hoveredElement.classList.remove('adshield-picker-target');
    }
    hoveredElement = e.target;
    hoveredElement.classList.add('adshield-picker-target');
  }

  function onZapperUnhover(e) {
    if (!zapperActive) return;
    if (e.target) {
      e.target.classList.remove('adshield-picker-target');
    }
  }

  function onZapperClick(e) {
    if (!zapperActive) return;
    if (e.target.closest('#adshield-zapper-banner')) return;

    e.preventDefault();
    e.stopPropagation();

    const target = e.target;
    target.classList.remove('adshield-picker-target');
    target.classList.add('adshield-zapped-element');
    target.style.display = 'none';

    const selector = generateSelector(target);

    ext.storage.local.get(['adshield_custom_rules'], (result) => {
      const customRules = result.adshield_custom_rules || {};
      if (!customRules[currentHost]) customRules[currentHost] = [];
      if (!customRules[currentHost].includes(selector)) {
        customRules[currentHost].push(selector);
        ext.storage.local.set({ adshield_custom_rules: customRules });
      }
    });

    blockedCountOnPage++;
    notifyBlockedAds(1);
    stopZapperMode();
  }

  function onZapperKeyDown(e) {
    if (e.key === 'Escape' && zapperActive) {
      stopZapperMode();
    }
  }

  function generateSelector(el) {
    if (el.id) return `#${CSS.escape(el.id)}`;
    if (el.className && typeof el.className === 'string') {
      const classes = el.className.split(/\s+/).filter(c => c && !c.startsWith('adshield-'));
      if (classes.length > 0) {
        return `${el.tagName.toLowerCase()}.${classes.map(c => CSS.escape(c)).join('.')}`;
      }
    }
    return el.tagName.toLowerCase();
  }

  // Listen for messages from popup or background
  ext.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'startZapper') {
      startZapperMode();
      sendResponse({ status: 'zapper_started' });
    } else if (message.action === 'getPageStats') {
      sendResponse({
        blockedCount: blockedCountOnPage,
        host: currentHost,
        isEnabled: isEnabled,
        isWhitelisted: isWhitelisted
      });
    }
  });

})();
