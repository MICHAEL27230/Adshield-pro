# AdShield Pro - Universal Ad & Tracker Blocker

**AdShield Pro** is an all-in-one browser extension built on the modern Manifest V3 standard. All code, configuration, rules, and tests are self-contained in this single folder.

It works across:
* **Mozilla Firefox**
* **Google Chrome**
* **Microsoft Edge**
* **Brave Browser**
* **Opera**

---

## 🦊 How to Install in Mozilla Firefox (30 Seconds)

1. Open **Mozilla Firefox**.
2. Type `about:debugging#/runtime/this-firefox` in the Firefox URL bar and press **Enter**.
3. Under the **"Temporary Extensions"** section, click **"Load Temporary Add-on..."**.
4. Browse to this folder and select [`manifest.json`](./manifest.json):
   ```text
   c:\Users\MICHAEL\OneDrive\Desktop\VIDE CODE\ANT GRAVITY\ad-blocker\manifest.json
   ```
5. **Done!** AdShield Pro is now active in Firefox.

---

## 🌐 How to Install in Google Chrome, Edge, Brave & Opera

1. Open **Chrome**, **Edge**, or **Brave**.
2. Navigate to your browser's extensions page:
   * **Chrome**: `chrome://extensions/`
   * **Edge**: `edge://extensions/`
   * **Brave**: `brave://extensions/`
3. Toggle ON **"Developer mode"** (top right corner).
4. Click **"Load unpacked"** (top left corner).
5. Select this entire [`ad-blocker`](./) folder.
6. **Done!** Pin the shield icon to your toolbar.

---

## 🧪 Interactive Test Laboratory

Open [`test-page.html`](./test-page.html) in any browser (Firefox or Chrome):
```text
file:///c:/Users/MICHAEL/OneDrive/Desktop/VIDE CODE/ANT GRAVITY/ad-blocker/test-page.html
```
The built-in audit system will test:
* **Google AdSense / DFP Banners**: Blocked and collapsed.
* **Sponsored Outbrain / Taboola recommendation grids**: Hidden.
* **300x250 Sidebar Ads**: Intercepted.
* **Sticky Floating Bottom Banners**: Eliminated.
* **Dynamic Ad Injections**: Blocked via `MutationObserver`.
* **⚡ Zap Element Tool**: Point and click to remove any custom element.

---

## 📁 File Structure

Everything is self-contained in this folder:
```text
ad-blocker/
├── manifest.json         # Universal Manifest V3 configuration (Firefox + Chrome)
├── rules.json            # 100+ Declarative Net Request ad/tracker blocking rules
├── background.js         # Cross-browser background service worker
├── content.js            # Dynamic DOM observer, element remover & video ad skipper
├── cosmetic-filters.css  # Instant layout cleanup and ad placeholder collapsing
├── popup.html            # Extension popup user interface
├── popup.css             # Dark modern shield UI styling
├── popup.js              # Controls power switch, whitelist, and stats
├── test-page.html        # Interactive ad-blocking test lab
├── README.md             # Universal installation & usage guide
└── icons/                # Extension icon set (16px, 48px, 128px)
```
