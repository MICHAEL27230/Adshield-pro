/**
 * AdShield Pro - Universal Popup UI Controller
 * Works across Mozilla Firefox, Google Chrome, Microsoft Edge, Brave, and Opera.
 */

document.addEventListener('DOMContentLoaded', async () => {
  const ext = typeof browser !== 'undefined' ? browser : chrome;

  const powerBtn = document.getElementById('powerBtn');
  const powerCard = document.getElementById('powerCard');
  const statusBadge = document.getElementById('statusBadge');
  const statusSub = document.getElementById('statusSub');
  const shieldIcon = document.getElementById('shieldIcon');
  const currentDomainEl = document.getElementById('currentDomain');
  const whitelistBtn = document.getElementById('whitelistBtn');
  const whitelistText = document.getElementById('whitelistText');
  const whitelistIcon = document.getElementById('whitelistIcon');
  const pageCountEl = document.getElementById('pageCount');
  const totalCountEl = document.getElementById('totalCount');
  const bannerCountEl = document.getElementById('bannerCount');
  const trackerCountEl = document.getElementById('trackerCount');
  const popupCountEl = document.getElementById('popupCount');
  const zapElementBtn = document.getElementById('zapElementBtn');
  const reloadTabBtn = document.getElementById('reloadTabBtn');
  const openTestPageBtn = document.getElementById('openTestPageBtn');
  const viewTestLabLink = document.getElementById('viewTestLabLink');

  let currentTab = null;
  let currentHost = '';
  let isGlobalEnabled = true;
  let isSiteWhitelisted = false;

  // 1. Get active tab
  try {
    const tabs = await ext.tabs.query({ active: true, currentWindow: true });
    if (tabs && tabs.length > 0) {
      currentTab = tabs[0];
      if (currentTab.url) {
        try {
          const parsed = new URL(currentTab.url);
          currentHost = parsed.hostname;
          currentDomainEl.textContent = currentHost || 'Current Tab';
        } catch (e) {
          currentDomainEl.textContent = 'System Page';
        }
      }
    }
  } catch (e) {}

  // 2. Load stored settings and statistics
  ext.storage.local.get(['adshield_enabled', 'adshield_whitelist', 'adshield_total_blocked', 'adshield_stats'], (data) => {
    isGlobalEnabled = data.adshield_enabled !== false;
    const whitelist = data.adshield_whitelist || [];
    isSiteWhitelisted = whitelist.includes(currentHost);

    totalCountEl.textContent = formatNumber(data.adshield_total_blocked || 0);

    const stats = data.adshield_stats || { banners: 0, trackers: 0, popups: 0 };
    bannerCountEl.textContent = formatNumber(stats.banners || 0);
    trackerCountEl.textContent = formatNumber(stats.trackers || 0);
    popupCountEl.textContent = formatNumber(stats.popups || 0);

    updatePowerUI();
    updateWhitelistUI();
  });

  // 3. Query current tab for active page block count
  if (currentTab && currentTab.id) {
    try {
      ext.tabs.sendMessage(currentTab.id, { action: 'getPageStats' }, (response) => {
        if (ext.runtime.lastError || !response) {
          ext.runtime.sendMessage({ action: 'getTabStats', tabId: currentTab.id }, (bgRes) => {
            if (bgRes && bgRes.count !== undefined) {
              pageCountEl.textContent = formatNumber(bgRes.count);
            }
          });
        } else {
          pageCountEl.textContent = formatNumber(response.blockedCount || 0);
        }
      });
    } catch (e) {}
  }

  // 4. Power switch click handler
  powerBtn.addEventListener('click', () => {
    isGlobalEnabled = !isGlobalEnabled;
    ext.runtime.sendMessage({ action: 'toggleProtection', enabled: isGlobalEnabled }, () => {
      updatePowerUI();
      refreshActiveTab();
    });
  });

  // 5. Whitelist button click handler
  whitelistBtn.addEventListener('click', () => {
    if (!currentHost || currentHost === 'System Page') return;

    ext.runtime.sendMessage({
      action: 'toggleWhitelist',
      domain: currentHost,
      tabId: currentTab ? currentTab.id : null
    }, (res) => {
      if (res) {
        isSiteWhitelisted = res.whitelisted;
        updateWhitelistUI();
        refreshActiveTab();
      }
    });
  });

  // 6. Zap Element mode
  zapElementBtn.addEventListener('click', () => {
    if (!currentTab || !currentTab.id) return;
    ext.tabs.sendMessage(currentTab.id, { action: 'startZapper' }, () => {
      window.close();
    });
  });

  // 7. Reload page
  reloadTabBtn.addEventListener('click', () => {
    refreshActiveTab();
  });

  // 8. Open Test Laboratory Page
  function openTestLab() {
    ext.tabs.create({ url: ext.runtime.getURL('test-page.html') });
  }

  openTestPageBtn.addEventListener('click', openTestLab);
  viewTestLabLink.addEventListener('click', (e) => {
    e.preventDefault();
    openTestLab();
  });

  // Helpers
  function updatePowerUI() {
    if (isGlobalEnabled && !isSiteWhitelisted) {
      powerBtn.classList.remove('disabled');
      powerBtn.classList.add('active');
      powerCard.classList.remove('paused');
      statusBadge.textContent = 'PROTECTION ACTIVE';
      statusBadge.classList.remove('disabled');
      statusSub.textContent = 'All ads & trackers are blocked';
      shieldIcon.style.background = 'linear-gradient(135deg, #10b981, #059669)';
      shieldIcon.style.boxShadow = '0 4px 12px rgba(16, 185, 129, 0.35)';
    } else {
      powerBtn.classList.add('disabled');
      powerBtn.classList.remove('active');
      powerCard.classList.add('paused');
      statusBadge.textContent = isSiteWhitelisted ? 'PAUSED ON THIS SITE' : 'PROTECTION OFF';
      statusBadge.classList.add('disabled');
      statusSub.textContent = isSiteWhitelisted ? 'Ads are allowed on this domain' : 'Ad filtering is globally disabled';
      shieldIcon.style.background = 'linear-gradient(135deg, #64748b, #475569)';
      shieldIcon.style.boxShadow = 'none';
    }
  }

  function updateWhitelistUI() {
    if (isSiteWhitelisted) {
      whitelistBtn.classList.add('whitelisted');
      whitelistIcon.textContent = '▶️';
      whitelistText.textContent = 'Resume AdShield';
    } else {
      whitelistBtn.classList.remove('whitelisted');
      whitelistIcon.textContent = '⏸️';
      whitelistText.textContent = 'Pause on Site';
    }
  }

  function refreshActiveTab() {
    if (currentTab && currentTab.id) {
      ext.tabs.reload(currentTab.id);
    }
  }

  function formatNumber(num) {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'k';
    return String(num);
  }
});
