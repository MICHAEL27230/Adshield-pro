/**
 * AdShield Pro - Universal Background Service Worker
 * Works across Mozilla Firefox, Google Chrome, Microsoft Edge, Brave, and Opera.
 */

// Cross-browser API adapter
const ext = typeof browser !== 'undefined' ? browser : chrome;

// In-memory tab counters
const tabBlockedCounts = {};

// Initialize defaults on install
ext.runtime.onInstalled.addListener(() => {
  ext.storage.local.get(['adshield_enabled', 'adshield_whitelist', 'adshield_total_blocked'], (data) => {
    if (data.adshield_enabled === undefined) {
      ext.storage.local.set({
        adshield_enabled: true,
        adshield_whitelist: [],
        adshield_total_blocked: 0,
        adshield_stats: {
          banners: 0,
          trackers: 0,
          popups: 0
        }
      });
    }
  });

  // Setup context menu
  try {
    ext.contextMenus.create({
      id: 'adshield_zap_element',
      title: '⚡ AdShield: Zap / Hide Element on this page',
      contexts: ['all']
    });

    ext.contextMenus.create({
      id: 'adshield_toggle_whitelist',
      title: '🛡️ AdShield: Whitelist / Pause on this site',
      contexts: ['all']
    });
  } catch (e) {}
});

// Context menu click handling
ext.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === 'adshield_zap_element' && tab && tab.id) {
    ext.tabs.sendMessage(tab.id, { action: 'startZapper' }).catch(() => {});
  } else if (info.menuItemId === 'adshield_toggle_whitelist' && tab && tab.url) {
    try {
      const url = new URL(tab.url);
      toggleDomainWhitelist(url.hostname, tab.id);
    } catch (e) {}
  }
});

// DeclarativeNetRequest Rule Matched Debug Listener (if available)
if (ext.declarativeNetRequest && ext.declarativeNetRequest.onRuleMatchedDebug) {
  try {
    ext.declarativeNetRequest.onRuleMatchedDebug.addListener((info) => {
      if (info && info.request && info.request.tabId > 0) {
        incrementTabCount(info.request.tabId, 1, 'network');
      }
    });
  } catch (e) {}
}

// Listen for messages from content scripts and popup
ext.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'adBlocked') {
    const tabId = sender.tab ? sender.tab.id : null;
    const count = message.count || 1;
    if (tabId) {
      incrementTabCount(tabId, count, 'cosmetic');
    }
    sendResponse({ received: true });
  } else if (message.action === 'getTabStats') {
    const tabId = message.tabId;
    const count = tabBlockedCounts[tabId] || 0;
    sendResponse({ count });
  } else if (message.action === 'toggleProtection') {
    handleToggleProtection(message.enabled, sendResponse);
    return true; // asynchronous response
  } else if (message.action === 'toggleWhitelist') {
    toggleDomainWhitelist(message.domain, message.tabId, sendResponse);
    return true; // asynchronous response
  }
});

/**
 * Increment tab blocked count and update badge
 */
function incrementTabCount(tabId, count, type) {
  if (!tabBlockedCounts[tabId]) {
    tabBlockedCounts[tabId] = 0;
  }
  tabBlockedCounts[tabId] += count;
  const currentTotal = tabBlockedCounts[tabId];

  // Update extension badge text
  try {
    ext.action.setBadgeText({
      text: currentTotal > 999 ? '999+' : String(currentTotal),
      tabId: tabId
    });
    ext.action.setBadgeBackgroundColor({
      color: '#ef4444', // Red badge
      tabId: tabId
    });
  } catch (e) {}

  // Update persistent stats
  ext.storage.local.get(['adshield_total_blocked', 'adshield_stats'], (data) => {
    const total = (data.adshield_total_blocked || 0) + count;
    const stats = data.adshield_stats || { banners: 0, trackers: 0, popups: 0 };

    if (type === 'network') {
      stats.trackers = (stats.trackers || 0) + count;
    } else {
      stats.banners = (stats.banners || 0) + count;
    }

    ext.storage.local.set({
      adshield_total_blocked: total,
      adshield_stats: stats
    });
  });
}

/**
 * Handle global enable/disable toggle
 */
function handleToggleProtection(enabled, callback) {
  ext.storage.local.set({ adshield_enabled: enabled }, () => {
    // Enable or disable the DNR ruleset
    if (ext.declarativeNetRequest && ext.declarativeNetRequest.updateEnabledRulesets) {
      const updatePromise = ext.declarativeNetRequest.updateEnabledRulesets({
        [enabled ? 'enableRulesetIds' : 'disableRulesetIds']: ['ad_rules']
      });

      if (updatePromise && typeof updatePromise.then === 'function') {
        updatePromise.then(() => {
          if (callback) callback({ success: true, enabled: enabled });
        }).catch(() => {
          if (callback) callback({ success: true, enabled: enabled });
        });
      } else {
        if (callback) callback({ success: true, enabled: enabled });
      }
    } else {
      if (callback) callback({ success: true, enabled: enabled });
    }
  });
}

/**
 * Toggle domain whitelisting
 */
function toggleDomainWhitelist(domain, tabId, callback) {
  if (!domain) return;

  ext.storage.local.get(['adshield_whitelist'], (data) => {
    let whitelist = data.adshield_whitelist || [];
    const index = whitelist.indexOf(domain);
    let isWhitelistedNow = false;

    if (index > -1) {
      whitelist.splice(index, 1);
      isWhitelistedNow = false;
    } else {
      whitelist.push(domain);
      isWhitelistedNow = true;
    }

    ext.storage.local.set({ adshield_whitelist: whitelist }, () => {
      // If whitelisted, clear tab badge
      if (isWhitelistedNow && tabId) {
        tabBlockedCounts[tabId] = 0;
        ext.action.setBadgeText({ text: 'OFF', tabId: tabId });
        ext.action.setBadgeBackgroundColor({ color: '#6b7280', tabId: tabId });
      }

      if (callback) callback({ whitelisted: isWhitelistedNow, domain: domain });
    });
  });
}

// Reset counts on navigation or tab close
ext.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status === 'loading') {
    tabBlockedCounts[tabId] = 0;
    try {
      ext.action.setBadgeText({ text: '', tabId: tabId });
    } catch (e) {}
  }
});

ext.tabs.onRemoved.addListener((tabId) => {
  delete tabBlockedCounts[tabId];
});
